# අවශ්‍යතා ලේඛනය

## 1. යෙදුම් දළ විශ්ලේෂණය

### 1.1 යෙදුම් නාමය
POShitha Pro

### 1.2 යෙදුම් විස්තරය
කඩවල් සහ සිල්ලර වෙළඳසැල් සඳහා නිර්මාණය කරන ලද Multi-Tenant Point of Sale (POS) සහ Inventory Management System එකකි. මෙම පද්ධතිය භාණ්ඩ විකිණීම, තොග කළමනාකරණය, ශාඛා කළමනාකරණය, සැපයුම්කරු කළමනාකරණය, විකුණුම් වාර්තා, ලාභ නිරීක්ෂණය, පද්ධති සැකසුම් කළමනාකරණය සහ බහු-කඩ (Multi-Tenant) සහාය සපයයි. සෑම shop එකක්ම සම්පූර්ණ data isolation සහිතව ස්වාධීනව ක්‍රියාත්මක වේ.

## 2. පරිශීලකයින් සහ භාවිත අවස්ථා

### 2.1 ඉලක්ක පරිශීලකයින්
- Shop Owner: කඩ හිමියා (shop registration, shop profile කළමනාකරණය, admin ක්‍රියාකාරීත්ව)
- Admin: පද්ධති පරිපාලකයා (භාණ්ඩ එකතු කිරීම, ශාඛා කළමනාකරණය, සැපයුම්කරු කළමනාකරණය, වාර්තා export කිරීම, backup කිරීම, ලාභ වාර්තා නිරීක්ෂණය)
- Cashier: මුදල් ලාච්චුකරු (විකිණීම් සිදු කිරීම, invoice නිකුත් කිරීම)
- Super Admin: පද්ධති මට්ටමේ පරිපාලකයා (සියලුම shops කළමනාකරණය, suspend/activate කිරීම)

### 2.2 ප්‍රධාන භාවිත අවස්ථා
- නව shop owner-කු register වී ස්වීය shop (tenant) create කිරීම
- Shop profile සහ subscription plan කළමනාකරණය
- සිල්ලර වෙළඳසැලක දෛනික විකිණීම් කළමනාකරණය
- භාණ්ඩ තොග නිරීක්ෂණය සහ යාවත්කාලීන කිරීම
- ශාඛා අනුව භාණ්ඩ සහ විකිණීම් කළමනාකරණය
- සැපයුම්කරුවන් කළමනාකරණය
- විකුණුම් වාර්තා නිරීක්ෂණය සහ විශ්ලේෂණය
- අඩු තොග ප්‍රමාණයන් හඳුනාගැනීම
- ලාභ නිරීක්ෂණය සහ විශ්ලේෂණය
- Super Admin විසින් සියලුම shops නිරීක්ෂණය සහ කළමනාකරණය

## 3. පිටු ව්‍යුහය සහ ක්‍රියාකාරීත්ව විස්තරය

### 3.1 පිටු ව්‍යුහය

```
POShitha Pro
├── Shop Registration පිටුව (නව)
├── Login පිටුව
├── Main Dashboard
│   ├── Billing (POS) පිටුව (යාවත්කාලීන කළ)
│   ├── Products පිටුව
│   ├── Branches පිටුව (Admin only)
│   ├── Suppliers පිටුව (Admin only)
│   ├── Reports පිටුව
│   ├── Users පිටුව (Admin only)
│   ├── Shop Profile පිටුව (නව - Shop Owner/Admin only)
│   └── Settings පිටුව
└── Super Admin Panel (නව - Super Admin only)
    └── Shops Management පිටුව
```

### 3.2 Shop Registration පිටුව (නව)

#### 3.2.1 ක්‍රියාකාරීත්වය
- Shop නාමය ඇතුළත් කිරීම
- Email ලිපිනය ඇතුළත් කිරීම
- මුරපදය ඇතුළත් කිරීම
- Register Shop බොත්තම
- සාර්ථක registration වීමෙන් පසු:
  - නව shop (tenant) record database එකේ සාදනු ලැබේ (shop_id, shop_name, email, created_at)
  - Shop owner account සාදනු ලැබේ (admin role සමඟ)
  - Login පිටුවට යොමු කිරීම
- Login පිටුවට යොමු කිරීමේ link

### 3.3 Login පිටුව

#### 3.3.1 ක්‍රියාකාරීත්වය
- Email ලිපිනය සහ මුරපදය ඇතුළත් කිරීමේ ක්ෂේත්‍ර
- Login බොත්තම
- Shop Registration පිටුවට යොමු කිරීමේ link
- සාර්ථක login වීමෙන් පසු:
  - පරිශීලකයාගේ shop_id හඳුනාගැනීම
  - Role අනුව access control සක්‍රීය කිරීම
  - Main Dashboard වෙත යොමු කිරීම (Super Admin නම් Super Admin Panel වෙත)

### 3.4 Billing (POS) පිටුව (යාවත්කාලීන කළ)

#### 3.4.1 ක්‍රියාකාරීත්වය

##### 3.4.1.1 භාණ්ඩ සෙවීම සහ එකතු කිරීම
- Barcode ඇතුළත් කිරීමේ ක්ෂේත්‍රය (auto-focus)
- Product Name සෙවීමේ search box (භාණ්ඩ නාමයෙන් සෙවීම)
- Barcode scan හෝ product name search කිරීමෙන් භාණ්ඩය cart එකට එකතු කිරීම (default qty = 1)
- Quick Product Buttons කලාපය:
  - Admin විසින් configure කරන ලද frequently used products shortcuts
  - Button click කිරීමෙන් භාණ්ඩය cart එකට එකතු කිරීම

##### 3.4.1.2 Cart Display කලාපය
- සෑම cart line item එකක් සඳහාම:
  - භාණ්ඩ නාමය
  - Unit (kg, pcs, ltr ආදිය)
  - ඒකක මිල (Rs. ලෙස)
  - ප්‍රමාණය (qty) edit කළ හැකි input field:
    - + / - buttons භාවිතයෙන් qty වැඩි/අඩු කිරීම
    - Direct input කිරීමේ හැකියාව
  - Discount field:
    - % හෝ amount ලෙස discount ඇතුළත් කිරීම
    - Discount apply කළ පසු line total යාවත්කාලීන වීම
  - Line Total (Rs. ලෙස, discount apply කළ පසු)
  - ඉතිරි තොග ප්‍රමාණය
  - Remove item බොත්තම
- Cart Total (Rs. ලෙස)

##### 3.4.1.3 Customer Info (විකල්ප)
- Customer Name ඇතුළත් කිරීමේ field
- Customer Phone Number ඇතුළත් කිරීමේ field
- Invoice print කරන විට customer info පෙන්වයි

##### 3.4.1.4 Payment Method සහ Checkout
- Payment Method තෝරාගැනීම: Cash / Card / Credit
- Cash payment තෝරාගත් විට:
  - Tendered Amount ඇතුළත් කිරීමේ field
  - Change Amount auto-calculate කිරීම (change = tendered - total)
- Invoice Preview බොත්තම:
  - Checkout කිරීමට පෙර invoice preview modal පෙන්වීම
  - Preview හි cart items, customer info, payment method, total පෙන්වයි
- Checkout බොත්තම (cart හි items තිබේ නම් පමණක්)
- Checkout සිදු කිරීමෙන් පසු:
  - Invoice record සාදනු ලැබේ (invoice_id, shop_id, total_amount, total_profit, cashier, items list, payment_method, branch_id, customer_name, customer_phone)
  - සෑම item එකක් සඳහාම profit ගණනය කරනු ලැබේ: (price - cost - discount) × qty
  - භාණ්ඩ තොග ප්‍රමාණය auto-reduce කිරීම
  - විකිණීම් දත්ත database එකේ සුරකිනු ලැබේ (shop_id සමඟ)
- Print Invoice බොත්තම (checkout සාර්ථක වූ පසු පෙන්වයි)
- Checkout සම්පූර්ණ වූ පසු barcode field එකට auto-focus යොමු කිරීම

##### 3.4.1.5 Hold / Resume Bill
- Hold Bill බොත්තම:
  - වත්මන් cart එක hold කර නව bill start කිරීම
  - Hold කළ bills list පෙන්වීම (invoice_id, customer name, total, held time)
- Resume Bill:
  - Hold කළ bills list එකෙන් bill එකක් තෝරාගෙන resume කිරීම
  - Resume කළ bill එකේ cart items, customer info යළි load කිරීම

##### 3.4.1.6 Day-End Summary (Cashier only)
- Day-End Summary බොත්තම:
  - අද දිනයේ cashier විසින් සිදු කළ විකිණීම් summary පෙන්වීම:
    - Total Sales (Rs.)
    - Total Cash (Rs.)
    - Total Card (Rs.)
    - Total Credit (Rs.)
    - Invoice Count

#### 3.4.2 Invoice Format
- Invoice ID
- Shop නාමය
- Customer Name (ඇතුළත් කළ නම්)
- Customer Phone (ඇතුළත් කළ නම්)
- භාණ්ඩ විස්තර (නාමය, unit, ප්‍රමාණය, ඒකක මිල, discount, line total)
- මුළු මිල
- Payment Method
- Change Amount (Cash payment නම්)
- දිනය සහ වේලාව
- Cashier නම
- Print-friendly layout

### 3.5 Products පිටුව

#### 3.5.1 ක්‍රියාකාරීත්වය
- භාණ්ඩ ලැයිස්තුව table view එකක් ලෙස පෙන්වීම (shop_id අනුව filter කරන ලද):
  - Barcode
  - භාණ්ඩ නාමය
  - Unit
  - ගැනුම් මිල (Cost Price - Rs.)
  - විකුණුම් මිල (Selling Price - Rs.)
  - තොග ප්‍රමාණය
  - Supplier නම
- Refresh බොත්තම (ලැයිස්තුව යාවත්කාලීන කිරීම)
- Add Product බොත්තම (Admin only):
  - Barcode ඇතුළත් කිරීම
  - භාණ්ඩ නාමය ඇතුළත් කිරීම
  - Unit ඇතුළත් කිරීම (kg, pcs, ltr ආදිය)
  - ගැනුම් මිල (Cost Price) ඇතුළත් කිරීම
  - විකුණුම් මිල (Selling Price) ඇතුළත් කිරීම
  - තොග ප්‍රමාණය ඇතුළත් කිරීම
  - Branch dropdown (ශාඛාව තෝරාගැනීම)
  - Supplier dropdown (සැපයුම්කරු තෝරාගැනීම)
  - Save කිරීමෙන් database එකට එකතු කිරීම (shop_id සමඟ)
- Edit Product (Admin only):
  - භාණ්ඩ විස්තර යාවත්කාලීන කිරීම
- Delete Product (Admin only):
  - භාණ්ඩය database එකෙන් ඉවත් කිරීම
- Export to Excel බොත්තම (Admin only):
  - භාණ්ඩ ලැයිස්තුව Excel file එකක් ලෙස download කිරීම
  - Excel columns: Barcode, Name, Unit, Cost Price, Selling Price, Qty, Supplier, Branch, Total Asset Value (qty × price), Profit Margin

### 3.6 Branches පිටුව (Admin only)

#### 3.6.1 ක්‍රියාකාරීත්වය
- ශාඛා ලැයිස්තුව table view එකක් ලෙස පෙන්වීම (shop_id අනුව filter කරන ලද):
  - ශාඛා නාමය
  - ලිපිනය
- Add Branch බොත්තම:
  - ශාඛා නාමය ඇතුළත් කිරීම
  - ලිපිනය ඇතුළත් කිරීම
  - Save කිරීමෙන් database එකට එකතු කිරීම (shop_id සමඟ)
- Edit Branch:
  - ශාඛා විස්තර යාවත්කාලීන කිරීම
- Delete Branch:
  - ශාඛාව database එකෙන් ඉවත් කිරීම

### 3.7 Suppliers පිටුව (Admin only)

#### 3.7.1 ක්‍රියාකාරීත්වය
- සැපයුම්කරු ලැයිස්තුව table view එකක් ලෙස පෙන්වීම (shop_id අනුව filter කරන ලද):
  - සැපයුම්කරු නාමය
  - දුරකථන අංකය
  - Email ලිපිනය
- Add Supplier බොත්තම:
  - සැපයුම්කරු නාමය ඇතුළත් කිරීම
  - දුරකථන අංකය ඇතුළත් කිරීම
  - Email ලිපිනය ඇතුළත් කිරීම
  - Save කිරීමෙන් database එකට එකතු කිරීම (shop_id සමඟ)
- Edit Supplier:
  - සැපයුම්කරු විස්තර යාවත්කාලීන කිරීම
- Delete Supplier:
  - සැපයුම්කරු database එකෙන් ඉවත් කිරීම

### 3.8 Reports පිටුව

#### 3.8.1 Today's Sales Report
- අද දිනයේ විකිණීම් ලැයිස්තුව (shop_id අනුව filter කරන ලද):
  - භාණ්ඩ නාමය
  - ප්‍රමාණය
  - මුළු මිල
  - Payment Method
  - Cashier
  - වේලාව
- මුළු විකිණීම් ගණන
- මුළු විකිණීම් මුදල (Rs.)

#### 3.8.2 අද ලාභය (Today's Profit - Admin Only)
- අද දිනයේ මුළු ලාභය (Rs.) stat card එකක් ලෙස පෙන්වීම (shop_id අනුව filter කරන ලද)
- Admin role ලෙස login වූ විට පමණක් පෙන්වයි
- Cashier role ට මෙම card එක නොපෙන්වයි

#### 3.8.3 Daily Report (Admin Only)
- Date picker භාවිතයෙන් දිනය තෝරාගැනීම
- තෝරාගත් දිනයේ (shop_id අනුව filter කරන ලද):
  - මුළු විකිණීම් මුදල (Total Sales - Rs.)
  - මුළු ලාභය (Total Profit - Rs.)
  - මුළු පිරිවැය (Total Cost - Rs.)
  - Invoice ගණන (Invoice Count)
- Branch filter (ශාඛාව අනුව filter කිරීම)

#### 3.8.4 Monthly Report (Admin Only)
- Year සහ Month තෝරාගැනීම
- තෝරාගත් මාසයේ (shop_id අනුව filter කරන ලද):
  - මුළු විකිණීම් මුදල (Total Sales - Rs.)
  - මුළු ලාභය (Total Profit - Rs.)
  - මුළු පිරිවැය (Total Cost - Rs.)
  - Invoice ගණන (Invoice Count)
- Branch filter (ශාඛාව අනුව filter කිරීම)

#### 3.8.5 Top Products (Admin Only)
- ඉහළම විකිණුම් ලත් භාණ්ඩ ලැයිස්තුව (shop_id අනුව filter කරන ලද):
  - භාණ්ඩ නාමය
  - විකුණූ ප්‍රමාණය (Qty)
  - මුළු විකිණීම් මුදල (Revenue - Rs.)
  - මුළු ලාභය (Profit - Rs.)

#### 3.8.6 Low Stock Alert
- තොග ප්‍රමාණය 10 ට අඩු භාණ්ඩ ලැයිස්තුව (shop_id අනුව filter කරන ලද):
  - භාණ්ඩ නාමය
  - වත්මන් තොග ප්‍රමාණය
  - Barcode

### 3.9 Users පිටුව (Admin only)

#### 3.9.1 ක්‍රියාකාරීත්වය
- පරිශීලක ලැයිස්තුව table view එකක් ලෙස පෙන්වීම (shop_id අනුව filter කරන ලද):
  - පරිශීලක නාමය
  - Role (Admin / Cashier)
- Role කළමනාකරණය:
  - පරිශීලකයාගේ role වෙනස් කිරීම

### 3.10 Shop Profile පිටුව (නව - Shop Owner/Admin only)

#### 3.10.1 ක්‍රියාකාරීත්වය
- Shop විස්තර display කිරීම සහ edit කිරීම:
  - Shop නාමය (edit කළ හැකිය)
  - Shop logo (image upload කළ හැකිය)
  - Contact info (දුරකථන අංකය, email, ලිපිනය - edit කළ හැකිය)
- Subscription Plan badge පෙන්වීම:
  - Free Plan හෝ Pro Plan (UI only indicator)
- Save Changes බොත්තම:
  - යාවත්කාලීන කළ විස්තර database එකේ සුරකිනු ලැබේ

### 3.11 Settings පිටුව

#### 3.11.1 ක්‍රියාකාරීත්වය
- Database Backup බොත්තම (Admin only):
  - Database backup file එකක් ලෙස download කිරීම (shop_id අනුව filter කරන ලද data)
- System Settings Panel:
  - පද්ධති සැකසුම් කළමනාකරණය
- Quick Product Buttons Configuration (Admin only):
  - Frequently used products තෝරාගැනීම
  - Quick buttons order සැකසීම
  - Save කිරීමෙන් configuration database එකේ සුරකිනු ලැබේ

### 3.12 Super Admin Panel (නව - Super Admin only)

#### 3.12.1 Shops Management පිටුව

##### 3.12.1.1 ක්‍රියාකාරීත්වය
- සියලුම shops ලැයිස්තුව table view එකක් ලෙස පෙන්වීම:
  - Shop ID
  - Shop නාමය
  - Email
  - Subscription Plan (Free / Pro)
  - Status (Active / Suspended)
  - Created දිනය
- Suspend Shop බොත්තම:
  - තෝරාගත් shop එක suspend කිරීම (status = suspended)
  - Suspended shop එකේ පරිශීලකයින්ට login කළ නොහැකිය
- Activate Shop බොත්තම:
  - Suspended shop එක activate කිරීම (status = active)
- View Shop Details:
  - Shop විස්තර සහ statistics පෙන්වීම

## 4. ව්‍යාපාර නීති සහ තාර්කිකත්වය

### 4.1 Multi-Tenant Data Isolation
- සෑම database table එකක්ම shop_id foreign key එකක් ඇතුළත් කරනු ලැබේ
- Products, Sales, Inventory, Customers, Suppliers, Branches, Users සියල්ල shop_id අනුව isolate කරනු ලැබේ
- Supabase RLS policies භාවිතයෙන් data access control සිදු කරනු ලැබේ:
  - පරිශීලකයාට තමන්ගේ shop_id සමඟ සම්බන්ධ data පමණක් access කළ හැකිය
  - Super Admin හැර අනෙකුත් shops හි data access කළ නොහැකිය

### 4.2 Role-based Access Control
- Shop Owner role:
  - Admin ක්‍රියාකාරීත්ව සියල්ල
  - Shop Profile කළමනාකරණය
- Admin role:
  - සියලුම ක්‍රියාකාරීත්ව වෙත ප්‍රවේශය (තමන්ගේ shop_id සඳහා පමණක්)
  - භාණ්ඩ CRUD
  - ශාඛා CRUD
  - සැපයුම්කරු CRUD
  - Export to Excel
  - Database backup
  - අද ලාභය (Today's Profit) නිරීක්ෂණය
  - Daily Report, Monthly Report, Top Products නිරීක්ෂණය
  - Users කළමනාකරණය
  - Quick Product Buttons configuration
- Cashier role:
  - Billing පිටුව පමණක් ප්‍රවේශ කළ හැකිය
  - භාණ්ඩ විකිණීම සහ invoice print කිරීම පමණක්
  - අද ලාභය (Today's Profit) නොපෙන්වයි
  - Admin-only reports නොපෙන්වයි
  - Day-End Summary නිරීක්ෂණය
- Super Admin role:
  - සියලුම shops කළමනාකරණය
  - Shops suspend/activate කිරීම
  - System-wide statistics නිරීක්ෂණය

### 4.3 තොග කළමනාකරණය
- භාණ්ඩයක් විකිණීමෙන් පසු තොග ප්‍රමාණය auto-reduce වේ
- තොග ප්‍රමාණය 10 ට අඩු වූ විට Low Stock Alert එකේ පෙන්වයි
- තොග ප්‍රමාණය 0 වූ විට විකිණීම සිදු කළ නොහැකිය

### 4.4 ලාභ ගණනය කිරීම
- සෑම item එකක් සඳහාම ලාභය = (විකුණුම් මිල - ගැනුම් මිල - discount) × ප්‍රමාණය
- Checkout time හි ලාභය ගණනය කර invoice record එකේ සුරකිනු ලැබේ
- අද දිනයේ මුළු ලාභය Reports පිටුවේ Admin role සඳහා පෙන්වයි
- Daily Report සහ Monthly Report හි මුළු ලාභය ගණනය කරනු ලැබේ

### 4.5 Invoice System
- Multi-item cart checkout කිරීමෙන් invoice record සාදනු ලැබේ
- Invoice record හි ඇතුළත් වන දත්ත:
  - invoice_id (unique)
  - shop_id (tenant identifier)
  - total_amount (මුළු විකිණීම් මුදල)
  - total_profit (මුළු ලාභය)
  - cashier (මුදල් ලාච්චුකරු නම)
  - items list (විකුණූ භාණ්ඩ ලැයිස්තුව, unit, discount සමඟ)
  - payment_method (Cash / Card / Credit)
  - branch_id (ශාඛා ID)
  - customer_name (විකල්ප)
  - customer_phone (විකල්ප)
  - tendered_amount (Cash payment නම්)
  - change_amount (Cash payment නම්)
  - දිනය සහ වේලාව

### 4.6 විකිණීම් දත්ත සුරැකීම
- සෑම විකිණීමක්ම database එකේ සුරකිනු ලැබේ:
  - shop_id (tenant identifier)
  - භාණ්ඩ නාමය
  - විකුණූ ප්‍රමාණය
  - මුළු මිල
  - ලාභය
  - Cashier නම
  - Payment Method
  - Branch ID
  - දිනය සහ වේලාව

### 4.7 ශාඛා සහ සැපයුම්කරු සම්බන්ධතා
- භාණ්ඩ ශාඛාවකට සම්බන්ධ කරනු ලැබේ (branch_id)
- භාණ්ඩ සැපයුම්කරුවකුට සම්බන්ධ කරනු ලැබේ (supplier_id)
- Invoice ශාඛාවකට සම්බන්ධ කරනු ලැබේ (branch_id)
- සියලු සම්බන්ධතා shop_id scope එක තුළ පවතී

### 4.8 මුදල් ඒකකය
- සියලුම මිල ගණන් Sri Lankan Rupees (Rs.) ලෙස පෙන්වයි

### 4.9 Payment Method
- Checkout කරන විට payment method තෝරාගැනීම අනිවාර්යයි
- Payment method options: Cash, Card, Credit
- Cash payment තෝරාගත් විට tendered amount ඇතුළත් කිරීම අනිවාර්යයි
- Change amount auto-calculate කරනු ලැබේ
- Invoice හි payment method සුරකිනු ලැබේ

### 4.10 Shop Registration සහ Tenant Creation
- නව shop owner-කු Shop Registration පිටුව හරහා register වේ
- Registration සාර්ථක වූ විට:
  - නව shop record සාදනු ලැබේ (shop_id, shop_name, email, status=active, plan=Free, created_at)
  - Shop owner account සාදනු ලැබේ (admin role සමඟ)
  - Shop owner-ට login කර තමන්ගේ shop කළමනාකරණය කළ හැකිය

### 4.11 Subscription Plan
- සෑම shop එකක්ම Free හෝ Pro plan එකක් සමඟ සම්බන්ධ වේ
- Shop Profile පිටුවේ plan badge පෙන්වයි (UI only indicator)
- මෙම අදියරේදී payment integration නොමැත

### 4.12 Super Admin Shop Management
- Super Admin-ට සියලුම shops ලැයිස්තුව බැලීමට හැකිය
- Super Admin-ට shops suspend/activate කළ හැකිය:
  - Suspended shop එකේ පරිශීලකයින්ට login කළ නොහැකිය
  - Active shop එකේ පරිශීලකයින්ට සාමාන්‍ය ලෙස access කළ හැකිය

### 4.13 PWA Offline Mode
- IndexedDB queue භාවිතයෙන් offline transactions සුරකිනු ලැබේ
- Online වූ විට queue එකේ transactions sync කරනු ලැබේ
- Offline mode හි shop_id සමඟ transactions සුරකිනු ලැබේ
- Offline mode හි product search, cart operations, hold/resume bills සියල්ල ක්‍රියාත්මක වේ

### 4.14 Product Search
- Barcode scan සහ product name search යන දෙකම භාවිතයෙන් භාණ්ඩ සෙවීම
- Search results shop_id අනුව filter කරනු ලැබේ

### 4.15 Cart Quantity Edit
- Cart line item එකක qty + / - buttons හෝ direct input භාවිතයෙන් edit කළ හැකිය
- Qty වෙනස් කළ විට line total auto-update වේ
- Qty වෙනස් කළ විට තොග ප්‍රමාණය validation සිදු කරනු ලැබේ

### 4.16 Line Item Discount
- සෑම cart line item එකක්ම discount apply කළ හැකිය
- Discount % හෝ amount ලෙස ඇතුළත් කළ හැකිය
- Discount apply කළ පසු line total යාවත්කාලීන වේ
- Profit calculation හි discount සැලකිල්ලට ගනු ලැබේ

### 4.17 Customer Info
- Customer name සහ phone number විකල්ප ලෙස ඇතුළත් කළ හැකිය
- Invoice print කරන විට customer info පෙන්වයි
- Customer info invoice record එකේ සුරකිනු ලැබේ

### 4.18 Invoice Preview
- Checkout කිරීමට පෙර invoice preview modal පෙන්වයි
- Preview හි cart items, customer info, payment method, total පෙන්වයි

### 4.19 Quick Product Buttons
- Admin විසින් frequently used products configure කළ හැකිය
- Quick buttons Billing පිටුවේ පෙන්වයි
- Button click කිරීමෙන් භාණ්ඩය cart එකට එකතු කරනු ලැබේ

### 4.20 Hold / Resume Bill
- වත්මන් cart එක hold කර නව bill start කළ හැකිය
- Hold කළ bills list පෙන්වයි
- Hold කළ bill එකක් resume කළ හැකිය
- Hold කළ bills shop_id සහ cashier අනුව filter කරනු ලැබේ

### 4.21 Day-End Summary
- Cashier විසින් අද දිනයේ සිදු කළ විකිණීම් summary නිරීක්ෂණය කළ හැකිය
- Summary හි total sales, payment method breakdown පෙන්වයි
- Summary shop_id සහ cashier අනුව filter කරනු ලැබේ

## 5. අසාමාන්‍ය සහ සීමාවන්

| අවස්ථාව | හැසිරීම |
|---------|----------|
| වැරදි barcode ඇතුළත් කිරීම | භාණ්ඩය හමු නොවූ බව පණිවිඩයක් පෙන්වීම |
| තොග ප්‍රමාණය 0 වූ භාණ්ඩයක් විකිණීමට උත්සාහ කිරීම | තොග නොමැති බව පණිවිඩයක් පෙන්වීම, විකිණීම සිදු නොකිරීම |
| Cashier role එකෙන් admin features වෙත ප්‍රවේශ වීමට උත්සාහ කිරීම | ප්‍රවේශය ප්‍රතික්ෂේප කිරීම |
| වැරදි login විස්තර ඇතුළත් කිරීම | වැරදි email හෝ password බව පණිවිඩයක් පෙන්වීම |
| භාණ්ඩ එකතු කිරීමේදී duplicate barcode ඇතුළත් කිරීම (same shop_id තුළ) | Barcode දැනටමත් පවතින බව පණිවිඩයක් පෙන්වීම |
| ගැනුම් මිල විකුණුම් මිලට වඩා වැඩි වීම | Admin භාණ්ඩ save කිරීමට පෙර අනතුරු ඇඟවීමක් පෙන්වීම |
| Cart හි items නොමැති විට checkout උත්සාහ කිරීම | Checkout බොත්තම disable කිරීම |
| Payment method තෝරාගැනීමකින් තොරව checkout උත්සාහ කිරීම | Payment method තෝරාගන්නා ලෙස පණිවිඩයක් පෙන්වීම |
| ශාඛාවක් delete කිරීමට උත්සාහ කරන විට එම ශාඛාවට සම්බන්ධ භාණ්ඩ හෝ invoices තිබේ නම් | Delete කළ නොහැකි බව පණිවිඩයක් පෙන්වීම |
| සැපයුම්කරුවකු delete කිරීමට උත්සාහ කරන විට එම සැපයුම්කරුට සම්බන්ධ භාණ්ඩ තිබේ නම් | Delete කළ නොහැකි බව පණිවිඩයක් පෙන්වීම |
| Suspended shop එකේ පරිශීලකයකු login වීමට උත්සාහ කිරීම | Shop suspended බව පණිවිඩයක් පෙන්වීම, login ප්‍රතික්ෂේප කිරීම |
| Shop Registration හි duplicate email භාවිතා කිරීම | Email දැනටමත් භාවිතා වන බව පණිවිඩයක් පෙන්වීම |
| Super Admin නොවන පරිශීලකයකු Super Admin Panel වෙත ප්‍රවේශ වීමට උත්සාහ කිරීම | ප්‍රවේශය ප්‍රතික්ෂේප කිරීම |
| Shop Profile හි logo upload කරන විට වැරදි file format භාවිතා කිරීම | සහාය දක්වන image formats පමණක් භාවිතා කරන ලෙස පණිවිඩයක් පෙන්වීම |
| Cart qty edit කරන විට තොග ප්‍රමාණයට වඩා වැඩි qty ඇතුළත් කිරීම | තොග ප්‍රමාණය ප්‍රමාණවත් නොවන බව පණිවිඩයක් පෙන්වීම |
| Cash payment තෝරාගෙන tendered amount ඇතුළත් නොකිරීම | Tendered amount ඇතුළත් කරන ලෙස පණිවිඩයක් පෙන්වීම |
| Tendered amount total amount ට වඩා අඩු වීම | Tendered amount ප්‍රමාණවත් නොවන බව පණිවිඩයක් පෙන්වීම |
| Discount % 100 ට වඩා වැඩි ඇතුළත් කිරීම | වලංගු discount % ඇතුළත් කරන ලෙස පණිවිඩයක් පෙන්වීම |
| Discount amount line total ට වඩා වැඩි ඇතුළත් කිරීම | වලංගු discount amount ඇතුළත් කරන ලෙස පණිවිඩයක් පෙන්වීම |
| Hold කළ bills නොමැති විට resume උත්සාහ කිරීම | Hold කළ bills නොමැති බව පණිවිඩයක් පෙන්වීම |
| Product name search හි results නොමැති වීම | Results නොමැති බව පණිවිඩයක් පෙන්වීම |

## 6. පිළිගැනීමේ ප්‍රමිතීන්

1. Shop Registration පිටුව භාවිතයෙන් නව shop එකක් register කිරීම (shop_name, email, password ඇතුළත් කර register කිරීම)
2. Register කළ shop owner account භාවිතයෙන් login වීම
3. Shop Profile පිටුවට ගොස් shop නාමය, logo, contact info යාවත්කාලීන කර save කිරීම
4. Branches පිටුවට ගොස් නව ශාඛාවක් එකතු කිරීම (name, address ඇතුළත් කර save කිරීම)
5. Suppliers පිටුවට ගොස් නව සැපයුම්කරුවකු එකතු කිරීම (name, phone, email ඇතුළත් කර save කිරීම)
6. Products පිටුවට ගොස් නව භාණ්ඩයක් එකතු කිරීම (barcode, name, unit, cost price, selling price, qty, branch, supplier ඇතුළත් කර save කිරීම)
7. Settings පිටුවේ Quick Product Buttons configuration භාවිතයෙන් frequently used products තෝරාගෙන save කිරීම
8. Billing පිටුවට ගොස් product name search box භාවිතයෙන් භාණ්ඩයක් සෙවීම සහ cart එකට එකතු කිරීම
9. Cart line item එකක qty + / - buttons භාවිතයෙන් edit කිරීම
10. Cart line item එකක discount (% හෝ amount) ඇතුළත් කිරීම
11. Customer name සහ phone number ඇතුළත් කිරීම
12. Payment method Cash තෝරාගෙන tendered amount ඇතුළත් කිරීම (change amount auto-calculate වීම පරීක්ෂා කිරීම)
13. Invoice Preview බොත්තම click කර preview modal පරීක්ෂා කිරීම
14. Checkout කර invoice print කිරීම (customer info, unit, discount, change amount පෙන්වීම පරීක්ෂා කිරීම)
15. Hold Bill බොත්තම භාවිතයෙන් වත්මන් bill hold කිරීම
16. නව bill start කර භාණ්ඩ එකතු කිරීම
17. Hold කළ bills list එකෙන් bill එකක් resume කිරීම
18. Day-End Summary බොත්තම භාවිතයෙන් cashier summary පරීක්ෂා කිරීම (total sales, payment method breakdown)
19. Reports පිටුවේ Daily Report හි date picker භාවිතයෙන් දිනයක් තෝරාගෙන total sales, total profit, total cost, invoice count පරීක්ෂා කිරීම
20. Super Admin account භාවිතයෙන් login වී Super Admin Panel වෙත ගොස් shops ලැයිස්තුව බැලීම
21. Super Admin Panel හි shop එකක් suspend කර, එම shop එකේ පරිශීලකයකු login වීමට උත්සාහ කරන විට login ප්‍රතික්ෂේප වීම පරීක්ෂා කිරීම

## 7. මෙම අදියරේදී ක්‍රියාත්මක නොකරන ක්‍රියාකාරීත්ව

- Subscription plan payment integration (Free/Pro plan UI indicator පමණක්)
- Shop-wise usage analytics හෝ billing
- Shop owner-ට users invite කිරීමේ system
- Shop logo file size හෝ format validation (basic validation පමණක්)
- Super Admin-ට shops edit කිරීමේ හැකියාව (suspend/activate පමණක්)
- Shop deletion functionality
- Shop data export හෝ migration tools
- Multi-language support (Sinhala පමණක්)
- Shop-wise custom branding හෝ themes
- Shop-wise API access හෝ integrations
- Shop owner-ට subscription plan upgrade/downgrade කිරීම
- Shop-wise data retention policies
- Shop-wise backup/restore functionality (system-wide backup පමණක්)
- Cross-shop data sharing හෝ collaboration
- Shop-wise notification preferences
- Customer database හෝ customer history tracking
- Barcode printing functionality
- Receipt printer integration
- Cash drawer integration
- Multi-currency support
- Tax calculation සහ tax reports
- Return/refund functionality
- Gift card හෝ voucher system
- Loyalty program integration
- Email/SMS invoice delivery
- Inventory transfer between branches
- Purchase order management
- Vendor payment tracking